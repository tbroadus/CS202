
void strCpy(char* dest, char* source);
bool strComp(char* str1, char* str2);
int strLength(char* string);
void strConcat(char* str1, char* str2);
